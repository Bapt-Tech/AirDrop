-- Déclaration du mod
airdrop = {}
local airdrop_timer = nil

-- Liste des items possibles avec leur indice de rareté (1 = très commun, 10 = très rare)
local possible_items = {
    {name = "mcl_tools:axe_netherite", rarity = 5},
    {name = "mcl_tools:pick_netherite", rarity = 5},
    {name = "mcl_tools:shovel_netherite", rarity = 5},
    {name = "mcl_tools:sword_netherite", rarity = 6},
    {name = "mcl_armor:boots_netherite", rarity = 4},
    {name = "mcl_armor:helmet_netherite", rarity = 4},
    {name = "mcl_armor:leggings_netherite", rarity = 7},
    {name = "mcl_armor:chestplate_netherite", rarity = 7},
    {name = "mcl_core:apple_gold_enchanted", rarity = 10},
    {name = "mcl_nether:netherite_ingot", rarity = 2},
    {name = "mcl_hamburger:hamburger", rarity = 3},
    {name = "mcl_totems:totem", rarity = 5},
    {name = "mcl_core:diamond", rarity = 2},
    {name = "mcl_core:emerald", rarity = 3},
    {name = "mcl_core:stick", rarity = 1},
    {name = "mcl_bows:rocket", rarity = 4},
    {name = "mcl_mobspawners:spawner", rarity = 10},
    {name = "mcl_armor:elytra", rarity = 10}
}

-- Fonction pour générer des items aléatoires en fonction de la rareté
local function get_random_items()
    local items = {}
    for _, item_info in ipairs(possible_items) do
        -- Calculer la probabilité d'apparition en fonction de la rareté
        local chance = 11 - item_info.rarity
        if math.random(1, 10) <= chance then
            local count = math.random(1, math.ceil(10 / item_info.rarity)) -- Nombre d'unités de cet item influencé par la rareté
            table.insert(items, {name = item_info.name, count = count})
        end
    end
    return items
end

-- Fonction pour générer le coffre avec des items aléatoires
function airdrop.spawn_airdrop(pos)
    -- Placer un bloc de diamant
    minetest.set_node(pos, {name = "mcl_core:diamondblock"})

    -- Création du coffre au-dessus du bloc de diamant
    local chest_pos = {x = pos.x, y = pos.y + 1, z = pos.z}
    minetest.set_node(chest_pos, {name = "mcl_chests:chest"})

    -- Ajout des items au coffre
    local chest_meta = minetest.get_meta(chest_pos)
    local inv = chest_meta:get_inventory()
    inv:set_size("main", 32)  -- S'assurer que l'inventaire a la bonne taille
    local items = get_random_items()
    
    local slots_filled = {}
    for _, item in ipairs(items) do
        local slot
        repeat
            slot = math.random(0, inv:get_size("main") - 1)
        until not slots_filled[slot]
        slots_filled[slot] = true
        inv:set_stack("main", slot + 1, item.name .. " " .. item.count)
    end
end

-- Définition du privilège 'airdrop'
minetest.register_privilege("airdrop", {
    description = "Allows the player to spawn airdrops",
    give_to_singleplayer = false
})

-- Commande /airdrop
minetest.register_chatcommand("airdrop", {
    description = "Spawns an airdrop structure with a chest at a random location within 1000 blocks of the spawn with items based on their rarity",
    privs = {airdrop=true},
    func = function(name)
        -- Génère une position aléatoire dans un rayon de 1000 blocs autour du spawn
        local pos = {
            x = math.random(-1000, 1000),
            y = math.random(50, 100),
            z = math.random(-1000, 1000)
        }

        -- Appelle la fonction pour générer l'airdrop
        airdrop.spawn_airdrop(pos)

        -- Informe le joueur
        local message = "-!- AirDrop -!- x: " .. pos.x .. " y: " .. pos.y .. " z: " .. pos.z
        minetest.chat_send_player(name, message)

        return true
    end,
})

-- Fonction pour lancer un airdrop automatique
local function start_auto_airdrop(interval)
    if not airdrop_timer then
        return
    end

    -- Génère une position aléatoire dans un rayon de 1000 blocs autour du spawn
    local pos = {
        x = math.random(-1000, 1000),
        y = math.random(50, 100),
        z = math.random(-1000, 1000)
    }

    -- Appelle la fonction pour générer l'airdrop
    airdrop.spawn_airdrop(pos)

    -- Informe tous les joueurs
    local message = "-!- Auto AirDrop -!- x: " .. pos.x .. " y: " .. pos.y .. " z: " .. pos.z
    minetest.chat_send_all(message)

    -- Planifie le prochain airdrop automatique
    airdrop_timer = minetest.after(interval * 60, start_auto_airdrop, interval)
end

-- Commande /auto_airdrop
minetest.register_chatcommand("auto_airdrop", {
    description = "Starts an automatic airdrop every specified number of minutes",
    privs = {airdrop=true},
    params = "<time>",
    func = function(name, param)
        local interval = tonumber(param)
        if interval and interval > 0 then
            if airdrop_timer then
                minetest.chat_send_player(name, "Auto airdrop is already running. Use /auto_airdrop_off to stop it first.")
            else
                airdrop_timer = minetest.after(interval * 60, start_auto_airdrop, interval)
                minetest.chat_send_player(name, "Auto airdrop started every " .. interval .. " minutes.")
            end
        else
            minetest.chat_send_player(name, "Invalid time. Please specify a positive number of minutes.")
        end
        return true
    end,
})

-- Commande /auto_airdrop_off
minetest.register_chatcommand("auto_airdrop_off", {
    description = "Stops the automatic airdrop",
    privs = {airdrop=true},
    func = function(name)
        if airdrop_timer then
            airdrop_timer = nil
            minetest.chat_send_player(name, "Auto airdrop stopped.")
        else
            minetest.chat_send_player(name, "Auto airdrop is not running.")
        end
        return true
    end,
})

-- Enregistre le mod
minetest.log("action", "[Airdrop] Mod loaded.")

